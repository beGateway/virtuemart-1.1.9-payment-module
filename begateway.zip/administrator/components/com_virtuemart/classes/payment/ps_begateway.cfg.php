<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 

define ('BGW_GW_DOMAIN', 'demo-gateway.begateway.com');
define ('BGW_PP_DOMAIN', 'checkout.begateway.com');
define ('BGW_SHOP_ID', '361');
define ('BGW_SHOP_KEY', 'b8647b68898b084b836474ed8d61ffe117c9a01168d867f24953b776ddcb134d');
define ('BGW_VERIFIED_STATUS', 'C');
define ('BGW_PENDING_STATUS', 'P');
define ('BGW_INVALID_STATUS', 'X');
?>