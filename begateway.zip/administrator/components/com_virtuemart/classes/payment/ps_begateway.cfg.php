<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' );

define ('BGW_GW_DOMAIN', '');
define ('BGW_PP_DOMAIN', '');
define ('BGW_SHOP_ID', '');
define ('BGW_SHOP_KEY', '');
define ('BGW_VERIFIED_STATUS', 'C');
define ('BGW_PENDING_STATUS', 'P');
define ('BGW_INVALID_STATUS', 'X');
?>
