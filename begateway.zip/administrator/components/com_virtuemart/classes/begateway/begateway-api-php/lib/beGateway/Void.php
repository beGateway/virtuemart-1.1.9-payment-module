<?php
class beGateway_Void extends beGateway_ChildTransaction {
}
?>
